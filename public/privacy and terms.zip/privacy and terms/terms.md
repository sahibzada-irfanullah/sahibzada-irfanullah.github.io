---
commentable: false
date: "2018-06-28T00:00:00+01:00"
draft: false
editable: false
header:
  caption: ""
  image: ""
share: false
title: Terms
---

Add your terms here and set `draft: false` to publish it. Otherwise, delete this file if you don't need it.
